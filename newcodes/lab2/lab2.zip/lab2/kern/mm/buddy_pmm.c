#include <pmm.h>
#include <list.h>
#include <string.h>
#include <assert.h>
#include <buddy_pmm.h>
#include <memlayout.h>
#include <stdio.h>  // 使用 cprintf

// 伙伴系统的全局自由链表
struct free_area buddy_free_area;

// 初始化伙伴系统
void buddy_init(void) {
    for (int i = 0; i <= MAX_ORDER; i++) {
        list_init(&buddy_free_area.free_list[i]);  // 初始化每个阶的自由链表
        buddy_free_area.nr_free[i] = 0;
    }
    print_buddy_status();  // 打印初始化后的伙伴系统状态
}


// 初始化内存块
void buddy_init_memmap(struct Page* base, size_t n) {
    assert(n > 0);
    cprintf("[DEBUG] Initializing memory map: base=%p, n=%lu\n", base, n);
    int order = MAX_ORDER;
    while ((1 << order) > n) {
        order--;  // 找到合适的阶数
    }

    base->order = order;
    list_add(&buddy_free_area.free_list[order], &base->page_link);
    buddy_free_area.nr_free[order]++;
}

// 打印伙伴系统的状态
void print_buddy_status(void) {
    cprintf("Buddy system status:\n");
    for (int i = 0; i <= MAX_ORDER; i++) {
        cprintf("Order %d: %lu free blocks\n", i, buddy_free_area.nr_free[i]);
    }
}

// 分配页面
struct Page* buddy_alloc_pages(size_t n) {
    assert(n > 0);
    cprintf("[INFO] Requesting to allocate %lu pages.\n", n);

    int order = 0;
    while ((1 << order) < n) {
        order++;  // 找到满足请求的最小阶数
    }
    
    cprintf("[INFO] Calculated order for %lu pages is %d.\n", n, order);

    for (int current_order = order; current_order <= MAX_ORDER; current_order++) {
        cprintf("[DEBUG] Checking free list at order %d.\n", current_order);
        if (!list_empty(&buddy_free_area.free_list[current_order])) {
            cprintf("[DEBUG] Found free block in order %d\n", current_order);
            // 找到合适的块，开始拆分
            list_entry_t* le = list_next(&buddy_free_area.free_list[current_order]);
            struct Page* page = le2page(le, page_link);
            list_del(le);  // 从当前阶级的自由链表中移除
            buddy_free_area.nr_free[current_order]--;
            cprintf("[INFO] Allocated block of order %d (size: %d pages) at address %p.\n",
                    current_order, (1 << current_order), page);

            // 如果阶数大于所需的阶数，进行拆分
            while (current_order > order) {
                current_order--;
                struct Page* buddy = page + (1 << current_order);
                buddy->order = current_order;
                list_add(&buddy_free_area.free_list[current_order], &buddy->page_link);
                buddy_free_area.nr_free[current_order]++;
                cprintf("[INFO] Split block: new block of order %d (size: %d pages) at address %p.\n",
                        current_order, (1 << current_order), buddy);
            }

            page->order = order;
            cprintf("[INFO] Final allocated block of order %d (size: %d pages) at address %p.\n",
                    order, (1 << order), page);
            return page;
        }
        else {
        cprintf("[DEBUG] No free block in order %d\n", current_order);
    }
    }

    cprintf("[ERROR] No suitable block found for allocation.\n");
    return NULL;  // 没有合适的块
}

// 释放页面
void buddy_free_pages(struct Page* base, size_t n) {
    assert(n > 0);
    cprintf("[INFO] Freeing %lu pages starting at address %p.\n", n, base);

    int order = 0;
    while ((1 << order) < n) {
        order++;
    }

    struct Page* page = base;
    while (order < MAX_ORDER) {
        struct Page* buddy = page + (1 << order);
        if (!list_empty(&buddy_free_area.free_list[order])) {
            // 如果找不到相邻的伙伴块，直接释放
            page->order = order;
            list_add(&buddy_free_area.free_list[order], &page->page_link);
            buddy_free_area.nr_free[order]++;
            cprintf("[INFO] Freed block of order %d (size: %d pages) at address %p.\n",
                    order, (1 << order), page);
            return;
        } else {
            // 如果找到相邻的伙伴块，合并
            list_del(&buddy->page_link);
            buddy_free_area.nr_free[order]--;
            if (page > buddy) {
                struct Page* temp = page;
                page = buddy;
                buddy = temp;
            }
            order++;
            cprintf("[INFO] Merged with buddy block: new order %d (size: %d pages) at address %p.\n",
                    order, (1 << order), page);
        }
    }

    page->order = order;
    list_add(&buddy_free_area.free_list[order], &page->page_link);
    buddy_free_area.nr_free[order]++;
    cprintf("[INFO] Freed merged block of order %d (size: %d pages) at address %p.\n",
            order, (1 << order), page);
}

// 获取空闲页数
size_t buddy_nr_free_pages(void) {
    size_t total_free = 0;
    for (int i = 0; i <= MAX_ORDER; i++) {
        total_free += buddy_free_area.nr_free[i] * (1 << i);
    }
    return total_free;
}

// 测试伙伴系统
void buddy_system_test() {
    cprintf("Running buddy system test...\n");

    struct Page* p1, * p2, * p3;

    buddy_init();
    cprintf("[INFO] Initialized buddy system.\n");

    // 初始化一个1024页的块
    buddy_init_memmap((struct Page*)0x1000, 1024);
    cprintf("[INFO] Initialized memory map for 1024 pages.\n");

    // 打印初始化后的状态
    print_buddy_status();  // 打印伙伴系统状态

    // 分配4页
    p1 = buddy_alloc_pages(4);
    if (p1 != NULL) {
        cprintf("[INFO] Allocated 4 pages.\n");
    }

    // 打印分配4页后的状态
    print_buddy_status();

    // 分配8页
    p2 = buddy_alloc_pages(8);
    if (p2 != NULL) {
        cprintf("[INFO] Allocated 8 pages.\n");
    }

    // 打印分配8页后的状态
    print_buddy_status();

    // 释放4页
    buddy_free_pages(p1, 4);
    cprintf("[INFO] Freed 4 pages.\n");

    // 打印释放4页后的状态
    print_buddy_status();

    // 释放8页
    buddy_free_pages(p2, 8);
    cprintf("[INFO] Freed 8 pages.\n");

    // 打印释放8页后的状态
    print_buddy_status();

    // 再次分配16页
    p3 = buddy_alloc_pages(16);
    if (p3 != NULL) {
        cprintf("[INFO] Allocated 16 pages.\n");
    }

    // 打印分配16页后的状态
    print_buddy_status();

    cprintf("[INFO] Buddy system test completed.\n");
}

// 定义 buddy_pmm_manager
const struct pmm_manager buddy_pmm_manager = {
    .name = "buddy_pmm_manager",
    .init = buddy_init,
    .init_memmap = buddy_init_memmap,
    .alloc_pages = buddy_alloc_pages,
    .free_pages = buddy_free_pages,
    .nr_free_pages = buddy_nr_free_pages,
    .check = buddy_system_test,  // 测试函数
};

